
def main():
    msg= str(input('Ingrese una fracción: '))
    x,y=msg.split('/')
    while x<=y :
        try:
            x=int(x)
            y=int(y)
            d=x/y
        except ValueError:
            print("Error dado que solo se permiten números enteros")
            return main()
        break
    while x>y:
        try:
            x=int(x)
            y=int(y)
            d=x/y
            return main()
        except ValueError:
            print("Error dado que solo se permiten números enteros")
            return main()
        except ZeroDivisionError:
            print('ZeroDivisionError')
            return main() 
        break
    d=x/y
    porcentaje=d*100
    porcentaje=int(porcentaje)
    if 1>=d>0.99:
       print('F')
    elif d<0.01:
       print('E')
    else:
        print(f'{porcentaje}%')    
    
main()


        