
lista=[]
def main():
    r=str(input('Desea ingresar una nota:'))
    while r=='si':
        n=(input('Ingrese una nota: '))
        try:
            n=int(n) 
            lista.append(n)
            return main()  
        except:
            print("Los valores introducidos no puedan ser convertidos debido a un error de tipeo o formato")
            return main()  
        break
    while r=='no':
        print(lista)
        break

main()
