
import math
class Punto:
    def __init__(self,x=0,y=0):
        self.x=x
        self.y=y
        
 
    
    def __str__(self):
        print(f'({self.x},{self.y})')
    def cuadrante(self):
        if self.x>0 and self.y>0:
            print('Pertenece al PRIMER CUADRANTE')
        elif self.x<0 and self.y>0:
            print('Pertenece al SEGUNDO CUADRANTE')
        elif self.x<0 and self.y<0:
            print('Pertenece al TERCER CUADRANTE')
        elif self.x>0 and self.y<0:
            print('Pertenece al CUARTO CUADRANTE')
        elif self.x!=0 and self.y==0:
            print('Pertenece al eje X')
        elif self.x==0 and self.y!=0:
            print('Pertenece al eje Y')
        else:
            print('Se encuentra en el origen de cordenadas')
    def vector(self,p):
        print(f'EL vector es ({p.x-self.x},{p.y-self.y})')

    def distancia(self,p):
        d=math.sqrt((p.x-self.x)**2+(p.y-self.y)**2)
        print(f'La distancia es {d}')



class Rectangulo:
    def __init__(self, a=Punto(), b=Punto()):
        self.a=a
        self.b=b    
    def base(self):
        self.base = abs(self.b.x - self.a.x)
        print(f"La base del rectángulo es {self.base}") 
    def altura(self):
        self.altura = abs(self.b.y - self.a.y)
        print(f"La altura del rectángulo es {self.altura}" )
    def area(self):
        self.base = abs(self.b.x - self.a.x)
        self.altura = abs(self.b.y - self.a.y)
        self.area = self.base * self.altura
        print("El área del rectángulo es {}".format( self.area ) )










