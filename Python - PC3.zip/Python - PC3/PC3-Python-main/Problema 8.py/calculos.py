import operaciones


a=3
b=4
operaciones.suma(a,b)
operaciones.resta(a,b)
operaciones.multiplicacion(a,b)
operaciones.division(a,b)


