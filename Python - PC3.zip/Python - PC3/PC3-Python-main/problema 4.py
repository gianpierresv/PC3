
    def __init__(self, alto, ancho):
        self.alto=alto
        self.ancho=ancho
    pass
    

    def area(self):
        a=self.alto*self.ancho
        print(f'El area es:{a}')
    pass
rect1 = rectangulo(3,4)
rect1.area()