
    def __init__(self, nombre, n_registro):
        self.nombre=str(nombre)
        self.n_registro=int(n_registro)
        self.edad=[]
        self.nota=[]
    pass
    
    def display(self):
        print(f'''Nombre: {self.nombre}   Numero de registro: {self.n_registro}''')
    def setAge(self, edad):
        self.edad.append(edad)
    def setNota(self, nota):
        self.nota.append(nota)
    
alumno1=Alumno('Piero',14)
alumno1.display()
alumno1.setAge(21)
alumno1.setNota(13)
print(f'edad {alumno1.edad}')
print(f'nota {alumno1.nota}')


  