import numeros_random

numeros_random.lista_random()