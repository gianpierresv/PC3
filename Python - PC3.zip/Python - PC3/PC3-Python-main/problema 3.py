
import math

class Circulo:
    
    pi=math.pi

    
    def __init__(self, radio) :
        self.radio=radio
    pass

    

    def calcula_area(self):
        a=math.pi*self.radio*self.radio
        print(f'El area es:{a}')
    pass


c1 = Circulo(3)
c1.calcula_area()


